<footer class="footer text-center py-2 theme-bg-dark">
		   
            <p class="copyright"><a href="http://blog.fariss.dk/">@copywrite 2022 Nadin fariss</a></p>
		   
	    </footer>
    
    </div>
 
 <?php
    wp_footer(); // wordpress gonna inject the files it needs for the page by itself from functions php file.
    ?>  


</body>
</html> 