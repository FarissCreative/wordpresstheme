// responsable for displaying and serving up comments in the theme.
