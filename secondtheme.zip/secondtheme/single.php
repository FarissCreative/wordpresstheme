// responsable for displaying single blog post
//when click on a individual blog post will display