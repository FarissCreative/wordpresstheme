// responsable to deliver an archive. 
// blog post: the index of all the blog posts in a hierarchical format that would be an archive page